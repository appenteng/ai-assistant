# backend/app/models/user.py
from sqlalchemy import Column, String, Boolean, JSON
from sqlalchemy.dialects.postgresql import UUID
import uuid
from .base import BaseModel


class User(BaseModel):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)

    # User preferences for travel planning
    preferences = Column(JSON, default={
        "budget_range": {"min": 0, "max": 5000},
        "travel_style": ["cultural", "relaxation"],
        "dietary_restrictions": [],
        "accessibility_needs": False,
        "preferred_accommodation": ["hotel"],
        "preferred_transport": ["flight"],
        "activities": ["sightseeing"],
        "climate_preference": "moderate"
    })